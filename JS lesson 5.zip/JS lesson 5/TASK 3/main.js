let num = +prompt('Enter number, bigger than 2');
res = [];
for(let i=2; i<=num; i++){
    res.push(i);
}


//ВАРИАНТ 1


let primeNumbers = [2, 3, 5, 7];
/*for (let i=0; i <=res.length; i++){
    if(res[i]%2 !=0 && res[i]%3 !=0 && res[i]%5 !=0 && res[i]%7 !=0){
        primeNumbers.push(res[i]);
    }
}
alert(`prime numbers are: ${primeNumbers}`)*/


//ВАРИАНТ 2


for(let i = 0; i <=res.length; i++){
    if(res[i] % 2 == 0){
        continue;
    }
    else if(res[i] % 3 == 0){
        continue;
    }
    else if(res[i] % 5 == 0){
        continue;
    }
    else if(res[i] % 7 == 0){
        continue;
    }
    primeNumbers.push(res[i])
}
alert(`Prime numbers are between 2 and ${num}: ${primeNumbers}`)
