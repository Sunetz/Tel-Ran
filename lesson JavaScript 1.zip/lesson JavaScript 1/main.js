//=========VARIABLES=======//

var age = 25; /*old methode*/
let message = "hello from main-js";
const PI = 3.14;


//Declaration

let userName;


//Initialisation

userName = "haha"
//const doesn't do that

console.log(0.2-0.1)

console.log(0.3-0.2)
let userAge = 25;
alert(4/2)

let string1 = "Hello,";
let string2 = " you";
let string3 = `Hello, `
alert(`Bye, ${string2}`)
alert(`summe 1 + 2 = ${1 + 2}`)

let nameFieldChecked = true;

let isGreat = 4 > userAge;

console.log(isGreat);

let currentAge = prompt('enter your age');
console.log(currentAge)
let dog;
console.log(dog);

//====Object, Synbol, Function===//

let x = 12;
const MONTH = 'july'
let isWeekend = false;
let price = null;
let cat;
console.log(typeof x);
console.log(typeof MONTH);
console.log(typeof isWeekend);
console.log(typeof price);
console.log(typeof cat);

//=========OPERATORS====//

let counter = 5;
let newCounter = counter--;
console.log(newCounter)
console.log(counter)

let num1 = prompt('enter')
let num2 = prompt('enter')
num1 = parseInt(num1)
num2 = parseInt(num2)
let sum = num1 + num2

alert('Summe, result is: ' + sum)