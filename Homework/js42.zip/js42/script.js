const setBtn = document.querySelector('#setBtn');

const daysTo = document.querySelector('.countDays');
const hoursTo = document.querySelector('.countHours');
const minutesTo = document.querySelector('.countMinutes');
const secondsTo = document.querySelector('.countSeconds');

setBtn.onclick = startTimer;

function startTimer(){
    
    let inputDate = document.querySelector('#date');
    let start = inputDate.value;
    document.querySelector('#text').innerHTML = 'Before your date left...';
    document.querySelector('.timer').classList.remove('hidden');
    const id = setInterval(renderTimer, 1000);
        
    function renderTimer(){
        
        const setDate = new Date(start);
        const now = new Date();
        const daysLeft = (setDate - now);
        const days = Math.floor(daysLeft / (24 * 60 * 60 * 1000)); 
        console.log(days);
        const hours = Math.floor((daysLeft / (60 * 60 * 1000)) % 24);
        const minutes = Math.floor((daysLeft / (60 * 1000)) % 60);
        const seconds = Math.floor((daysLeft / 1000) % 60);
        
        if(daysLeft===0){
            document.querySelector('.timer').classList.add('hidden');
            document.querySelector('#text').innerHTML = 'Time is over';
            clearInterval(id);
            }
        else{            
            daysTo.innerHTML = days;
            hoursTo.innerHTML = hours;
            minutesTo.innerHTML = minutes;
            secondsTo.innerHTML = seconds;
            
        }
        
    }
}