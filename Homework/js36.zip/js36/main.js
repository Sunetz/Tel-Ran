const UserInput = document.querySelector('#input'),
    btnSet = document.querySelector('#set');
    const ul = document.querySelector('#list');
//let films = [];

btnSet.onclick = ()=>{
    const li = document.createElement('li');
    ul.innerHTML += `<li>${UserInput.value}</li>`;
    
}
