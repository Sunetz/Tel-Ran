function Person(id, name, phone, email, city, description) {
    this.id = id,
    this.name = name,
    this.phone = phone,
    this.email = email,
    this.city = city,
    this.description = description
};
const Mercedes = new Person(0, 'Mrs Mercedes', '1029834566', 'merc@gmail.com', 'Berlin', 'car dealer');
const Honda = new Person(1, 'Mr Honda', '1029837463','honda@gmail.com', 'Tokio', 'motocycle engines');
const Java = new Person(2, 'Mrs Java', '1029234566','java@gmail.com', 'Bonn', 'it-girl');
const Bond = new Person(3, 'Mr Bond', '1029234007','bond007@gmail.com', 'London', 'Agent 007');
const message = document.querySelector('.message');

let persons = [Mercedes, Honda, Java, Bond];


const btnContacts = document.querySelector('.btnContacts');
const btnAdd = document.querySelector('.btnAdd');
const info = document.querySelector('.info-area');
const shortInfo = document.querySelector('.short-info');
const fullInfo = document.querySelector('.full-info');

renderShortInfo();

btnContacts.onclick=(event)=>{
    renderShortInfo();//==========================call function
    info.classList.remove('hide');
    userForm.classList.add('hide');
    event.currentTarget.classList.add('active');
    btnAdd.classList.remove('active');
    
    
}
btnAdd.onclick = (event)=>{
    info.classList.add('hide');
    userForm.classList.remove('hide');
    event.currentTarget.classList.add('active');
    btnContacts.classList.remove('active');

    renderAddForm();//==========================call function
}



function renderShortInfo(){
    shortInfo.innerHTML = '';
    persons.forEach((element, index) => {
        //console.log(element, index);
        const div = document.createElement('div');
        div.id = 'person_' + index;
        console.log(persons)
        div.classList.add('person');
        div.innerHTML += `<div class="main-side">
        <h3>${element.name}</h3>
        <p>${element.phone}</p></div><div class="remove-side">
        <i class="fas fa-trash"></i></div>`;
        shortInfo.append(div);
        const contacts = shortInfo.querySelectorAll('.person');

for(contact of contacts){
    contact.onclick = (event)=>{
    
    fullInfo.innerHTML = '';    
    event.currentTarget.classList.add('active');
    
    const id = +event.currentTarget.id.split("_")[1];
    const element = persons.find((p)=> p.id === id);
    const personDetail = document.createElement('div');
    personDetail.classList.add('inner');
    personDetail.innerHTML = `
    <h3>${element.name}</h3>                    
    <div id="phone"><i class="fas fa-phone"></i>${element.phone}</div>                   
    <div id="email"><i class="fas fa-envelope"></i>${element.email}</div>                    
    <div id="city"><i class="fas fa-city"></i>${element.city}</div>
    <div id="descript">${element.description}</div>
    `;
    fullInfo.append(personDetail);
        
    if(event.target.classList.contains('fa-trash')){
        event.currentTarget.classList.add('hide');
        shortInfo.removeChild(event.currentTarget);
        fullInfo.removeChild(personDetail);
        
        persons.splice(persons.findIndex(((p)=>p.id === id)), 1);  
    };
}    
}
    });
}

const userForm = document.querySelector('.form-area');
const btnAddContact  = document.querySelector('#btnAdd');

function renderAddForm(){
    btnAddContact.onclick = (event)=>{
        event.preventDefault();  
        const inputs = userForm.querySelectorAll('input');   
        
        const newContact = {
            id: persons.length
        }
        
        for(input of inputs){
            
            newContact[input.id] = input.value;
            input.value = '';
            console.log(newContact);
        }
        persons.push(newContact);
    }
}




