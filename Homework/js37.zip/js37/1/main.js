let containerBox = document.querySelector('.container-1');

let num = +prompt('enter a number');
let clicks = 0;
for(let i=0; i<num; i++){    
    let box = document.createElement('div');    
    box.classList.add('box');
    containerBox.append(box);
    box.innerHTML = `${i+1}`;
    
    box.onclick = function(e){
        e.target.remove();
    }
}




