const btnStart = document.querySelector('#start');
const btnStop = document.querySelector('#stop');
const inputNumber = document.querySelector('#inputNum');
const counter = document.querySelector('#counter');

btnStart.onclick=startTimer;
btnStop.onclick=stopTimer;


function startTimer(){
    btnStart.disabled = true;
    btnStart.classList.add('disabled');
    let count = +inputNumber.value+1;
    const id = setInterval(timer, 1000);
    
    
    function timer(){
        if(count===0){
            counter.innerHTML = 'Time is over';
            counter.style.paddingTop = '20px';
            clearInterval(id);
            btnStart.disabled = false;
            btnStart.classList.remove('disabled');
        }
        
        else{count--;
        counter.innerHTML = `${count}`;}
        
    }
    return id;
    
}

function stopTimer(){
    btnStop.disabled = true;
    btnStop.classList.add('disabled');
    btnStart.disabled = false;
    btnStart.classList.remove('disabled');
    

}
