//========================TASK 1==========================//

let a = prompt ('First number?', 1);
let b = prompt ('Second number?', 2);

firstNum = +a
secondNum = +b

alert(`Summe ${a} + ${b} = ${firstNum + secondNum}`)



//========================TASK 2===========================//


let salaryPerHour = +prompt('How much do you get per a hour?', 0)
let workHours = +prompt('How many hours do you work per a day?', 0)

alert(`You monthly income is ${salaryPerHour * workHours * 22} euro`)


//=======================TASK 3============================//

const PI = 3.1415
let radius = +prompt('Enter radius', 0)
let roundSquare = PI*(radius**2)
alert (`The square of your round is ${roundSquare}`)

