arr = [1, 2, 5, 6];
//бинарный поиск через рекурсию
function binarySearch(someArr, num){
    Math.floor(someArr.length/2)
}