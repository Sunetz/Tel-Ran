let numberOfFilms;

const personalMovieDB = {
    count: numberOfFilms, //=========================считается undefined. Почему?========//
    movies:{ },  // {'Titanic': 8.8, 'Hattika' : 9.4}
    genres:[],
    private: false,
    sayHello: function(){
        alert('Hello!')
    },
    getMovieData: function(filmsNum){
        for(let i=0; i<filmsNum; i++){
            const title = prompt('Enter the title of last watched movie'),
                rate = parseFloat(prompt('How do you rate it?'));
                console.log(rate)
            if(title != null && title != '' && rate != null && rate !=''&& !isNaN(rate) ){
                personalMovieDB.movies[title] = rate;
            }else{
                alert('write correct data')
                i--;
            }
        }
    },
    getGenre: function(number){
        for (let i = 1; i <= number; i++){
            personalMovieDB.genres[i-1] = prompt(`What is your top-${number} genre?`)
        }
    },
    showMovieDB: function(){
        if(!this.private){
            //console.log(personalMovieDB);
            alert(`You did watched: ${this.count} films`);
            for(let key in personalMovieDB.movies){ 
                alert(`You saved film: '${key}' has rate ${personalMovieDB.movies[key]}`)
            }
            alert(`You favorite genre: ${personalMovieDB.genres}`);
            alert(levelScoreMessage(personalMovieDB.count));
        }
    },
    levelScoreMessage: function(moviesCount){
        if(moviesCount < 5){
            return 'don\'t like movies?'
        }else if(moviesCount >=5 && moviesCount <=15){
            return 'you are classic viewer\u{1F60D}'
        }else if (moviesCount > 15 && moviesCount<=30){
            return 'you\'re a movie buff!';
        }else{
            return 'error'
        }
    }
}

function start(){
    do{
    numberOfFilms = +prompt('How many films did you watch last month?')
    }while(isNaN(numberOfFilms));
}


start();
console.log(personalMovieDB.count);

/*personalMovieDB.sayHello();
personalMovieDB.getGenre(3);
personalMovieDB.getMovieData(3);
personalMovieDB.showMovieDB();
*/
