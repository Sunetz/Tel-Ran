let numb;
const myHonda = {
    wheels: numb,
};


function start(){
    do{
    numb = +prompt('give a number')
    }while(isNaN(numb))
}
console.log(typeof(myHonda.wheels))