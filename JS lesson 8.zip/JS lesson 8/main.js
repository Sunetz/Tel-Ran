//Task02
/* написать функцию, которая корачивает строку (если слово длиннее, чем maxLength - обрезать до maxLength и добавит ... , если короче - вернуть изначальную строку)
    function stringCat(str, maxLength);

    stringCat('hello world!', 5) -> 'hello...'
    stringCat('hello', 5) -> 'hello'
*/
let newstr = prompt('Say something');
let maxLength = Number(prompt('Maximal length of string must be...?'));

function stringCat(string, Number){
    if(string.length > Number){
        document.write(string.slice(0, maxLength) + '...');
    }else{
        document.write(string)
    }
}

stringCat(newstr, maxLength);


//Task03
/* 
    игра русско-английский словарь;
    двухмерный массив с парами слов (всего пять пар)
    спрашивать пользователя перевод английского слова из массива, если ответ правильный - выводить "Отлично!", если нет - правильный перевод слова
*/

let dictionary = [['defender', 'защитник'],['forward', 'нападающий'],['halfback','полузащитник'],['referee','судья'],['reserves bench','скамейка запасных']];
function translateWords(array){
    loop1:
    for(i=0; i < array.length; i++){
        let translation = prompt(`Translate ${array[i][0]} from english to russian`);
        
        if(translation === null || translation ===''){
            break loop1;
        }else{
            if(translation == dictionary[i][1]){
                alert('Perfect!')
            }else{
                alert(`Wrong. The correct translation is ${array[i][1]}`);
            }
        }
    }
}

translateWords(dictionary);
